Nik Visuals 3.1.3 — CLEAN source for Minecraft 1.21.11

Restored:
- Valid gradlew / gradlew.bat / gradle-wrapper.jar (Gradle 8.12)
- ModConfig.java, NikVisuals.java, NikVisualsClient.java (real Java)
- LineWidth fix (no crash on block outline)
- GuiOverlayMixin with Sprite
- All 33 .java files brace-checked

Build (Java 21):
  gradlew.bat build

Jar:
  build\libs\nikvisuals-3.1.3.jar
