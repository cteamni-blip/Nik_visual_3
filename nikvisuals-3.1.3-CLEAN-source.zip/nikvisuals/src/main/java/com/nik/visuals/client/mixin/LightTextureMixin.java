package com.nik.visuals.client.mixin;

import com.nik.visuals.client.config.ModConfig;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(LightmapTextureManager.class)
public class LightTextureMixin {
    @ModifyVariable(method = "update", at = @At("STORE"), ordinal = 0, require = 0)
    private float nik$fb(float gamma) {
        try {
            if (ModConfig.fullbright) return 16f;
        } catch (Throwable ignored) {}
        return gamma;
    }
}
