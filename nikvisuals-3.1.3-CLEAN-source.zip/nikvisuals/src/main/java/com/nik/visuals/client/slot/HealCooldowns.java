package com.nik.visuals.client.slot;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.HashMap;
import java.util.Map;

@Environment(EnvType.CLIENT)
public final class HealCooldowns {
    private static final Map<String, long[]> CD = new HashMap<>();

    private HealCooldowns() {}

    public static void clear() { CD.clear(); }

    public static void tick() {
        long now = System.currentTimeMillis();
        CD.entrySet().removeIf(e -> e.getValue()[0] <= now);
    }

    public static void onFinish(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return;
        if ((stack.isOf(Items.POTION) || stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION))
                && isHealingPotion(stack)) {
            CD.put("potion_heal", new long[]{System.currentTimeMillis() + 10000L, 10000L});
        }
    }

    private static boolean isHealingPotion(ItemStack stack) {
        try {
            PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
            if (contents == null) return false;
            for (StatusEffectInstance e : contents.getEffects()) {
                if (e.getEffectType() == StatusEffects.INSTANT_HEALTH
                        || e.getEffectType() == StatusEffects.REGENERATION
                        || e.getEffectType() == StatusEffects.HEALTH_BOOST) {
                    return true;
                }
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    public static float[] queryPotionHeal() {
        long[] v = CD.get("potion_heal");
        if (v == null) return null;
        long now = System.currentTimeMillis();
        long left = v[0] - now;
        if (left <= 0) return null;
        float progress = (float) left / (float) v[1];
        return new float[]{progress, left / 1000f};
    }

    public static boolean matchesPotionSlot(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        return stack.isOf(Items.POTION) || stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION);
    }
}
