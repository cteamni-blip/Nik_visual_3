package com.nik.visuals.client.pulse;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

@Environment(EnvType.CLIENT)
public class PulseManager {
    private float lastHealth = 20.0f;
    private long damageUntil;

    public void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        float hp = p.getHealth();
        if (hp < this.lastHealth - 0.1f) {
            this.damageUntil = System.currentTimeMillis() + 450L;
        }
        this.lastHealth = hp;
    }

    public void renderHud(DrawContext g, float pt) {
        float ratio;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        long now = System.currentTimeMillis();
        if (ModConfig.damagePulse && now < this.damageUntil) {
            float t = (float)(this.damageUntil - now) / 450.0f;
            int a = (int)(t * 90.0f);
            int c = a << 24 | ModConfig.damagePulseColor & 0xFFFFFF;
            g.fill(0, 0, sw, 3, c);
            g.fill(0, sh - 3, sw, sh, c);
            g.fill(0, 0, 3, sh, c);
            g.fill(sw - 3, 0, sw, sh, c);
        }
        if (ModConfig.lowHealthPulse && (ratio = p.getHealth() / p.getMaxHealth()) <= ModConfig.lowHealthThreshold) {
            float pulse = (float)(0.4 + 0.6 * Math.abs(Math.sin((double)now / 250.0)));
            int a = (int)(pulse * 70.0f * ModConfig.pulseIntensity);
            int c = a << 24 | ModConfig.lowHealthColor & 0xFFFFFF;
            g.fill(0, 0, sw, 4, c);
            g.fill(0, sh - 4, sw, sh, c);
        }
    }
}

