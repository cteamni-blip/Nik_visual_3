package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

@Environment(EnvType.CLIENT)
public class TargetHUD {
    private LivingEntity target;
    private float appear;
    private float hpSmooth = 1f;
    private float flash;
    private int lastX, lastY, lastW = 120, lastH = 40;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }
    public int scaledW() { return lastW; }
    public int scaledH() { return lastH; }

    public void tick(MinecraftClient mc) {
        LivingEntity next = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity le && le.isAlive()) next = le;
        }
        // keep last target briefly
        if (next != null) target = next;
        else if (target != null && (!target.isAlive() || target.squaredDistanceTo(mc.player) > 400)) target = null;

        boolean show = ModConfig.targetHud && target != null || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.18f);
        if (target != null) {
            float hp = target.getHealth() / Math.max(1f, target.getMaxHealth());
            float prev = hpSmooth;
            hpSmooth = Anim.approach(hpSmooth, hp, 0.15f);
            if (hpSmooth < prev - 0.02f) flash = 1f;
        }
        flash = Anim.approach(flash, 0f, 0.12f);
    }

    public void render(DrawContext g, float pt) {
        if (appear < 0.02f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float a = Anim.easeOutCubic(appear);
        float scale = Math.max(0.7f, Math.min(1.5f, ModConfig.targetHudScale));

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int bw = 128, bh = 42;
        int x, y;
        if (ModConfig.targetHudX < 0) {
            x = sw / 2 - bw / 2;
            y = 12;
        } else {
            x = (int) (ModConfig.targetHudX * sw);
            y = (int) (ModConfig.targetHudY * sh);
        }
        lastX = x; lastY = y; lastW = (int)(bw * scale); lastH = (int)(bh * scale);

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x, y);
        g.getMatrices().scale(scale);

        int panel = Style.alpha(Style.PANEL, a);
        int border = Style.alpha(Style.ACCENT_GLOW);
        GuiDraw.glassPanel(g, 0, 0, bw, bh, 8, panel, border);
        if (flash > 0.05f) {
            g.fill(1, 1, bw - 1, bh - 1, Style.solidAlpha(0xCC4444, (int)(50 * flash * a)));
        }

        String name = target != null ? target.getName().getString() : "Target";
        if (name.length() > 14) name = name.substring(0, 13) + "…";
        g.drawText(mc.textRenderer, name, 28, 8, Style.alpha(Style.TEXT, a), false);

        // head placeholder square with accent
        GuiDraw.fillRounded(g, 6, 6, 18, 18, 4, Style.alpha(Style.GLASS, a));
        g.fill(6, 6, 8, 24, Style.alpha(Style.ACCENT, a));
        try {
            if (target instanceof AbstractClientPlayerEntity pl) {
                // skin draw may vary by version — safe fallback already drawn
            }
        } catch (Throwable ignored) {}

        float hp = target != null ? hpSmooth : 0.7f;
        int barColor = hp > 0.5f ? Style.OK : (hp > 0.25f ? Style.WARN : Style.DANGER);
        GuiDraw.hpBar(g, 28, 22, 90, 7, hp, Style.alpha(barColor, a), Style.alpha(Style.TRACK_OFF, a));

        String hpText = target != null
                ? String.format("%.0f/%.0f", target.getHealth(), target.getMaxHealth())
                : "—/—";
        g.drawText(mc.textRenderer, hpText, 28, 31, Style.alpha(Style.TEXT_DIM, a), false);

        if (ModConfig.showDistance && target != null && mc.player != null) {
            String dist = String.format("%.1fm", mc.player.distanceTo(target));
            g.drawText(mc.textRenderer, dist, bw - 8 - mc.textRenderer.getWidth(dist), 8, Style.alpha(Style.TEXT_DIM, a), false);
        }

        g.getMatrices().popMatrix();
    }

    public void onHurt(LivingEntity e) {
        if (e == target) flash = 1f;
    }
}
