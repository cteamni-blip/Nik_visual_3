package com.nik.visuals.client.swap;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class TalismanSwapHandler {
    private static final long SWAP_COOLDOWN_MS = 750L;
    private long lastSwapMs = 0L;
    private boolean wasDown;
    private int hovered = -1;
    private final List<Candidate> candidates = new ArrayList<Candidate>();
    private boolean mouseWasDown;
    private String statusMsg = null;
    private long statusUntil = 0L;

    public void tick(MinecraftClient mc, boolean keyDown) {
        if (!ModConfig.talismanSwap || mc.player == null || mc.currentScreen != null) {
            this.wasDown = false;
            this.candidates.clear();
            this.hovered = -1;
            this.mouseWasDown = false;
            return;
        }
        if (keyDown) {
            boolean mouseDown;
            if (!this.wasDown) {
                this.rebuildCandidates(mc.player);
                this.hovered = this.candidates.isEmpty() ? -1 : 0;
            }
            this.updateHover(mc);
            boolean bl = mouseDown = GLFW.glfwGetMouseButton((long)mc.getWindow().getHandle(), (int)0) == 1;
            if (mouseDown && !this.mouseWasDown && this.hovered >= 0 && this.hovered < this.candidates.size()) {
                this.trySwap(mc, this.candidates.get(this.hovered));
                this.wasDown = false;
                this.candidates.clear();
                this.hovered = -1;
                this.mouseWasDown = true;
                return;
            }
            this.mouseWasDown = mouseDown;
            this.wasDown = true;
        } else {
            if (this.wasDown && this.hovered >= 0 && this.hovered < this.candidates.size()) {
                this.trySwap(mc, this.candidates.get(this.hovered));
            }
            this.wasDown = false;
            this.candidates.clear();
            this.hovered = -1;
            this.mouseWasDown = false;
        }
    }

    private void trySwap(MinecraftClient mc, Candidate c) {
        long now = System.currentTimeMillis();
        if (now - this.lastSwapMs < 750L) {
            this.statusMsg = "\u00a7c\u041f\u043e\u0434\u043e\u0436\u0434\u0438\u2026";
            this.statusUntil = now + 600L;
            return;
        }
        if (this.swapToOffhand(mc, c)) {
            this.lastSwapMs = now;
            this.statusMsg = null;
        }
    }

    private void rebuildCandidates(ClientPlayerEntity player) {
        this.candidates.clear();
        for (int i = 0; i < 36; ++i) {
            ItemStack st = player.getInventory().getStack(i);
            if (st.isEmpty() || !TalismanSwapHandler.isSwapItem(st)) continue;
            this.candidates.add(new Candidate(i, st));
        }
    }

    public static boolean isSwapItem(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        String name = stack.getName().getString().toLowerCase();
        if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
            boolean defaultName;
            boolean bl = defaultName = name.equals("totem of undying") || name.equals("\u0442\u043e\u0442\u0435\u043c \u0431\u0435\u0441\u0441\u043c\u0435\u0440\u0442\u0438\u044f") || name.equals("totem") || name.equals("\u0442\u043e\u0442\u0435\u043c");
            if (defaultName) {
                return false;
            }
            return TalismanSwapHandler.nameMatches(name);
        }
        if (TalismanSwapHandler.nameMatches(name)) {
            return true;
        }
        try {
            String id = Registries.ITEM.getId(stack.getItem()).getPath();
            if (id.equals("totem_of_undying")) {
                return false;
            }
            if (id.contains("talisman") || id.contains("charm") || id.contains("amulet") || id.contains("sphere") || id.contains("orb")) {
                return true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private static boolean nameMatches(String name) {
        return name.contains("\u0442\u0430\u043b\u0438\u0441\u043c\u0430\u043d") || name.contains("talisman") || name.contains("\u0430\u043c\u0443\u043b\u0435\u0442") || name.contains("charm") || name.contains("\u043e\u0431\u0435\u0440\u0435\u0433") || name.contains("\u0440\u0435\u043b\u0438\u043a\u0432") || name.contains("pendant") || name.contains("\u0441\u0444\u0435\u0440\u0430") || name.contains("sphere") || name.contains("orb") || name.contains("\u0448\u0430\u0440") || name.contains("crystal") || name.contains("\u043a\u0440\u0438\u0441\u0442\u0430\u043b\u043b");
    }

    private void updateHover(MinecraftClient mc) {
        double cy;
        double dy;
        if (this.candidates.isEmpty()) {
            this.hovered = -1;
            return;
        }
        double mx = mc.mouse.getX();
        double my = mc.mouse.getY();
        double cx = (double)mc.getWindow().getWidth() / 2.0;
        double dx = mx - cx;
        if (Math.hypot(dx, dy = my - (cy = (double)mc.getWindow().getHeight() / 2.0)) < 36.0) {
            this.hovered = -1;
            return;
        }
        double ang = Math.atan2(dy, dx) + 1.5707963267948966;
        if (ang < 0.0) {
            ang += Math.PI * 2;
        }
        int n = this.candidates.size();
        this.hovered = (int)(ang / (Math.PI * 2 / (double)n)) % n;
    }

    private boolean swapToOffhand(MinecraftClient mc, Candidate c) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.interactionManager == null || mc.getNetworkHandler() == null) {
            return false;
        }
        try {
            int slot = this.findLiveSlot(player, c);
            if (slot < 0) {
                return false;
            }
            if (ItemStack.areItemsAndComponentsEqual((ItemStack)player.getOffHandStack(), (ItemStack)player.getInventory().getStack(slot))) {
                return false;
            }
            if (slot >= 0 && slot < 9) {
                int prev = player.getInventory().getSelectedSlot();
                player.getInventory().setSelectedSlot(slot);
                mc.getNetworkHandler().sendPacket((Packet)new UpdateSelectedSlotC2SPacket(slot));
                mc.getNetworkHandler().sendPacket((Packet)new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
                player.getInventory().setSelectedSlot(prev);
                mc.getNetworkHandler().sendPacket((Packet)new UpdateSelectedSlotC2SPacket(prev));
            } else {
                int syncId = player.playerScreenHandler.syncId;
                mc.interactionManager.clickSlot(syncId, slot, 40, SlotActionType.SWAP, (PlayerEntity)player);
            }
            return true;
        }
        catch (Throwable t) {
            t.printStackTrace();
            return false;
        }
    }

    private int findLiveSlot(ClientPlayerEntity player, Candidate c) {
        ItemStack st;
        int i;
        for (i = 0; i < 36; ++i) {
            st = player.getInventory().getStack(i);
            if (st.isEmpty() || !ItemStack.areItemsAndComponentsEqual((ItemStack)st, (ItemStack)c.stack)) continue;
            return i;
        }
        for (i = 0; i < 36; ++i) {
            st = player.getInventory().getStack(i);
            if (st.isEmpty() || !TalismanSwapHandler.isSwapItem(st) || !st.getName().getString().equals(c.stack.getName().getString())) continue;
            return i;
        }
        return -1;
    }

    public void render(DrawContext g, float pt) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) {
            return;
        }
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int cx = sw / 2;
        int cy = sh / 2;
        long now = System.currentTimeMillis();
        if (this.statusMsg != null && now < this.statusUntil) {
            g.drawCenteredTextWithShadow(mc.textRenderer, this.statusMsg, cx, cy + 50, -1);
        }
        if (!ModConfig.talismanSwap || !this.wasDown) {
            return;
        }
        int outerR = 70;
        for (int a = 0; a < 360; a += 2) {
            double rad = Math.toRadians(a);
            int x = cx + (int)Math.round(Math.cos(rad) * (double)outerR);
            int y = cy + (int)Math.round(Math.sin(rad) * (double)outerR);
            g.fill(x, y, x + 2, y + 2, -2000976132);
        }
        GuiDraw.fillSoftCircle(g, cx, cy, 26, -871757804);
        GuiDraw.fillSoftCircle(g, cx, cy, 24, -300806628);
        g.drawCenteredTextWithShadow(mc.textRenderer, "\u00a7dSWAP", cx, cy - 8, -2043649);
        long left = 750L - (now - this.lastSwapMs);
        if (left > 0L && this.lastSwapMs > 0L) {
            g.drawCenteredTextWithShadow(mc.textRenderer, "\u00a7c" + String.format("%.1f", Float.valueOf((float)left / 1000.0f)) + "s", cx, cy + 4, -21846);
        } else {
            g.drawCenteredTextWithShadow(mc.textRenderer, this.candidates.isEmpty() ? "\u00a78\u043f\u0443\u0441\u0442\u043e" : "\u00a77\u043a\u043b\u0438\u043a / \u043e\u0442\u043f\u0443\u0441\u0442\u0438", cx, cy + 4, -5592406);
        }
        if (this.candidates.isEmpty()) {
            return;
        }
        int n = this.candidates.size();
        double radius = 58.0;
        for (int i = 0; i < n; ++i) {
            double ang = -1.5707963267948966 + (double)i * (Math.PI * 2 / (double)n);
            int ix = cx + (int)(Math.cos(ang) * radius);
            int iy = cy + (int)(Math.sin(ang) * radius);
            boolean sel = i == this.hovered;
            int box = sel ? 26 : 20;
            GuiDraw.fillRounded(g, ix - box / 2 - 2, iy - box / 2 - 2, box + 4, box + 4, 6, sel ? -4487428 : 0x66FFFFFF);
            GuiDraw.fillRounded(g, ix - box / 2, iy - box / 2, box, box, 5, -267252196);
            g.drawItem(this.candidates.get((int)i).stack, ix - 8, iy - 8);
            if (!sel) continue;
            Object name = this.candidates.get((int)i).stack.getName().getString();
            if (((String)name).length() > 20) {
                name = ((String)name).substring(0, 19) + "\u2026";
            }
            int tw = mc.textRenderer.getWidth((String)name);
            GuiDraw.fillRounded(g, cx - tw / 2 - 6, cy + 36, tw + 12, 14, 5, -587202560);
            g.drawCenteredTextWithShadow(mc.textRenderer, (String)name, cx, cy + 39, -1);
        }
    }

    @Environment(EnvType.CLIENT)
    public static class Candidate {
        final int invSlot;
        final ItemStack stack;

        Candidate(int invSlot, ItemStack stack) {
            this.invSlot = invSlot;
            this.stack = stack.copy();
        }
    }
}

