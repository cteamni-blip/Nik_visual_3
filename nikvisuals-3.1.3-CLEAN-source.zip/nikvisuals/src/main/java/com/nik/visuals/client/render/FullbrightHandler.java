package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;

@Environment(EnvType.CLIENT)
public class FullbrightHandler {
    public void tick(MinecraftClient mc) {
        if (mc == null || mc.options == null) return;
        try {
            SimpleOption<Double> gamma = mc.options.getGamma();
            double v = gamma.getValue();
            // clamp illegal values from old fullbright
            if (v > 1.0 || v < 0.0) {
                gamma.setValue(1.0);
            } else if (ModConfig.fullbright && v < 1.0) {
                gamma.setValue(1.0);
            }
        } catch (Throwable ignored) {}
    }
}
