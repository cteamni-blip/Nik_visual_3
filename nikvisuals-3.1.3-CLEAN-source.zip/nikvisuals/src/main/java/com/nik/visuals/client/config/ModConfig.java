package com.nik.visuals.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Environment(EnvType.CLIENT)
public final class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("nikvisuals.json");

    public static boolean showCoords = true;
    public static boolean blockOutline = true;
    public static boolean trajectory = true;
    public static boolean targetHud = true;
    public static boolean damagePulse = true;
    public static boolean lowHealthPulse = true;
    public static boolean showDistance = true;
    public static boolean showArmor = true;
    public static boolean slotTimer = true;
    public static boolean slotTimerOverlay = true;
    public static boolean ambience = true;
    public static boolean clearEffects = false;
    public static boolean fullbright = false;
    public static boolean potions = true;
    public static boolean optimizePvp = false;
    public static boolean watermark = true;
    public static boolean saturationHud = true;
    public static boolean armorHud = true;
    public static boolean inventoryHud = true;
    public static boolean armorWarn = true;
    public static boolean talismanSwap = true;
    public static boolean colorFilter = false;
    public static boolean layoutEdit = false;
    public static boolean uiSounds = true;

    public static int weatherMode = 0;
    public static int filterColor = 0x4477FF;
    public static int talismanKey = GLFW.GLFW_KEY_LEFT_ALT;
    public static int trajectoryColor = 0x88CCAA;
    public static int damagePulseColor = 0xFF33C55A;
    public static int lowHealthColor = 0xFFAA2234;
    public static int hudBg = 0xCC101814;
    public static int hudBorder = 0xFF3DCC7A;
    public static int preset = 1;

    public static float filterIntensity = 0.25f;
    public static float slotTimerScale = 0.85f;
    public static float ambienceIntensity = 0.35f;
    public static float menuScale = 1f;
    public static float targetHudScale = 1f;
    public static float potionsScale = 1f;
    public static float inventoryHudScale = 1f;
    public static float pulseSpeed = 1.2f;
    public static float pulseIntensity = 0.85f;
    public static float lowHealthThreshold = 0.3f;

    public static float targetHudX = -1f;
    public static float targetHudY = -1f;
    public static float potionsX = 0.02f;
    public static float potionsY = 0.25f;
    public static float watermarkX = 0.5f;
    public static float watermarkY = 0.02f;
    public static float inventoryHudX = 0.02f;
    public static float inventoryHudY = 0.55f;

    private ModConfig() {}

    public static void applyPreset(int id) {
        preset = id;
        if (id == 0) {
            targetHud = true; potions = true; watermark = true;
            trajectory = false; blockOutline = false; ambience = false;
            damagePulse = false; inventoryHud = false; slotTimer = true;
            optimizePvp = false;
        } else if (id == 2) {
            targetHud = true; potions = true; watermark = true;
            trajectory = true; blockOutline = true; ambience = true;
            damagePulse = true; inventoryHud = true; slotTimer = true;
            optimizePvp = true; showArmor = true; showDistance = true;
        } else {
            targetHud = true; potions = true; watermark = true;
            trajectory = true; blockOutline = true; ambience = true;
            damagePulse = true; inventoryHud = true; slotTimer = true;
            optimizePvp = false;
        }
        save();
    }

    public static void load() {
        if (!Files.exists(PATH)) {
            save();
            return;
        }
        try {
            Data d = GSON.fromJson(Files.readString(PATH), Data.class);
            if (d == null) return;
            showCoords = d.showCoords;
            blockOutline = d.blockOutline;
            trajectory = d.trajectory;
            targetHud = d.targetHud;
            damagePulse = d.damagePulse;
            lowHealthPulse = d.lowHealthPulse;
            showDistance = d.showDistance;
            showArmor = d.showArmor;
            slotTimer = d.slotTimer;
            slotTimerOverlay = d.slotTimerOverlay;
            ambience = d.ambience;
            clearEffects = d.clearEffects;
            fullbright = d.fullbright;
            potions = d.potions;
            optimizePvp = d.optimizePvp;
            watermark = d.watermark;
            saturationHud = d.saturationHud;
            armorHud = d.armorHud;
            inventoryHud = d.inventoryHud;
            armorWarn = d.armorWarn;
            talismanSwap = d.talismanSwap;
            colorFilter = d.colorFilter;
            uiSounds = d.uiSounds;
            weatherMode = d.weatherMode;
            filterColor = d.filterColor;
            talismanKey = d.talismanKey;
            trajectoryColor = d.trajectoryColor;
            damagePulseColor = d.damagePulseColor;
            lowHealthColor = d.lowHealthColor;
            hudBg = d.hudBg;
            hudBorder = d.hudBorder;
            preset = d.preset;
            filterIntensity = d.filterIntensity;
            slotTimerScale = d.slotTimerScale;
            ambienceIntensity = d.ambienceIntensity;
            menuScale = d.menuScale;
            targetHudScale = d.targetHudScale;
            potionsScale = d.potionsScale;
            inventoryHudScale = d.inventoryHudScale;
            pulseSpeed = d.pulseSpeed;
            pulseIntensity = d.pulseIntensity;
            lowHealthThreshold = d.lowHealthThreshold;
            targetHudX = d.targetHudX;
            targetHudY = d.targetHudY;
            potionsX = d.potionsX;
            potionsY = d.potionsY;
            watermarkX = d.watermarkX;
            watermarkY = d.watermarkY;
            inventoryHudX = d.inventoryHudX;
            inventoryHudY = d.inventoryHudY;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        Data d = new Data();
        d.showCoords = showCoords;
        d.blockOutline = blockOutline;
        d.trajectory = trajectory;
        d.targetHud = targetHud;
        d.damagePulse = damagePulse;
        d.lowHealthPulse = lowHealthPulse;
        d.showDistance = showDistance;
        d.showArmor = showArmor;
        d.slotTimer = slotTimer;
        d.slotTimerOverlay = slotTimerOverlay;
        d.ambience = ambience;
        d.clearEffects = clearEffects;
        d.fullbright = fullbright;
        d.potions = potions;
        d.optimizePvp = optimizePvp;
        d.watermark = watermark;
        d.saturationHud = saturationHud;
        d.armorHud = armorHud;
        d.inventoryHud = inventoryHud;
        d.armorWarn = armorWarn;
        d.talismanSwap = talismanSwap;
        d.colorFilter = colorFilter;
        d.uiSounds = uiSounds;
        d.weatherMode = weatherMode;
        d.filterColor = filterColor;
        d.talismanKey = talismanKey;
        d.trajectoryColor = trajectoryColor;
        d.damagePulseColor = damagePulseColor;
        d.lowHealthColor = lowHealthColor;
        d.hudBg = hudBg;
        d.hudBorder = hudBorder;
        d.preset = preset;
        d.filterIntensity = filterIntensity;
        d.slotTimerScale = slotTimerScale;
        d.ambienceIntensity = ambienceIntensity;
        d.menuScale = menuScale;
        d.targetHudScale = targetHudScale;
        d.potionsScale = potionsScale;
        d.inventoryHudScale = inventoryHudScale;
        d.pulseSpeed = pulseSpeed;
        d.pulseIntensity = pulseIntensity;
        d.lowHealthThreshold = lowHealthThreshold;
        d.targetHudX = targetHudX;
        d.targetHudY = targetHudY;
        d.potionsX = potionsX;
        d.potionsY = potionsY;
        d.watermarkX = watermarkX;
        d.watermarkY = watermarkY;
        d.inventoryHudX = inventoryHudX;
        d.inventoryHudY = inventoryHudY;
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(d));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class Data {
        boolean showCoords = true, blockOutline = true, trajectory = true, targetHud = true;
        boolean damagePulse = true, lowHealthPulse = true, showDistance = true, showArmor = true;
        boolean slotTimer = true, slotTimerOverlay = true, ambience = true, clearEffects = false;
        boolean fullbright = false, potions = true, optimizePvp = false, watermark = true;
        boolean saturationHud = true, armorHud = true, inventoryHud = true, armorWarn = true;
        boolean talismanSwap = true, colorFilter = false, uiSounds = true;
        int weatherMode = 0, filterColor = 0x4477FF, talismanKey = 342, trajectoryColor = 0x88CCAA;
        int damagePulseColor = 0xFF33C55A, lowHealthColor = 0xFFAA2234, hudBg = 0xCC101814, hudBorder = 0xFF3DCC7A;
        int preset = 1;
        float filterIntensity = 0.25f, slotTimerScale = 0.85f, ambienceIntensity = 0.35f, menuScale = 1f;
        float targetHudScale = 1f, potionsScale = 1f, inventoryHudScale = 1f, pulseSpeed = 1.2f;
        float pulseIntensity = 0.85f, lowHealthThreshold = 0.3f;
        float targetHudX = -1f, targetHudY = -1f, potionsX = 0.02f, potionsY = 0.25f;
        float watermarkX = 0.5f, watermarkY = 0.02f, inventoryHudX = 0.02f, inventoryHudY = 0.55f;
    }
}
