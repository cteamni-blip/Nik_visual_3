package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class TrajectoryRenderer {
    public void renderWorld(MatrixStack poseStack, VertexConsumerProvider buffers, float pt) {
        try {
        if (!ModConfig.trajectory) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || buffers == null || poseStack == null || mc.currentScreen != null) {
            return;
        }
        Kind k = this.detect(player);
        if (k == null) {
            return;
        }
        Vec3d eye = player.getCameraPosVec(pt);
        Vec3d start = k.pearl ? eye.add(0.0, -0.15, 0.0) : eye;
        Vec3d look = player.getRotationVec(pt);
        List<Double> angles = k.multishot ? List.of(Double.valueOf(-10.0), Double.valueOf(0.0), Double.valueOf(10.0)) : List.of(Double.valueOf(0.0));
        Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
        poseStack.push();
        Matrix4f m = poseStack.peek().getPositionMatrix();
        VertexConsumer lines = buffers.getBuffer(RenderLayers.lines());
        for (double ang : angles) {
            SimResult res = this.simulate(player, start, this.rotateYaw(look, ang), k);
            if (res.path.size() < 2) continue;
            this.draw(lines, m, cam, res.path, res.hitEntity);
        }
        poseStack.pop();
    }

    private Kind detect(ClientPlayerEntity player) {
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();
        if (main.isOf(Items.ENDER_PEARL) || off.isOf(Items.ENDER_PEARL)) {
            return new Kind(1.5, 0.03, 0.99f, false, true);
        }
        ItemStack xb = null;
        if (main.isOf(Items.CROSSBOW)) xb = main;
        else if (off.isOf(Items.CROSSBOW)) xb = off;
        if (xb != null) {
            ChargedProjectilesComponent ch = xb.get(DataComponentTypes.CHARGED_PROJECTILES);
            if (ch != null && !ch.isEmpty()) {
                return new Kind(3.15, 0.05, 0.99f, this.hasMulti(xb), false);
            }
        }
        if ((main.getItem() instanceof BowItem || off.getItem() instanceof BowItem)
                && player.isUsingItem()
                && player.getActiveItem().getItem() instanceof BowItem) {
            float pull = BowItem.getPullProgress(player.getItemUseTime());
            if (pull > 0.1f) {
                return new Kind((double) pull * 3.0, 0.05, 0.99f, false, false);
            }
        }
        return null;
    }

    
    private boolean hasMulti(ItemStack stack) {
        try {
            ItemEnchantmentsComponent e = stack.get(DataComponentTypes.ENCHANTMENTS);
            if (e == null) return false;
            for (var en : e.getEnchantmentEntries()) {
                String k = String.valueOf(en.getKey()).toLowerCase();
                if (k.contains("multishot")) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }


    private Vec3d rotateYaw(Vec3d dir, double degrees) {
        if (Math.abs(degrees) < 0.01) {
            return dir;
        }
        double rad = Math.toRadians(degrees);
        double cos = Math.cos(rad);
        double sin = Math.sin(rad);
        return new Vec3d(dir.x * cos - dir.z * sin, dir.y, dir.x * sin + dir.z * cos).normalize();
    }

    private SimResult simulate(ClientPlayerEntity player, Vec3d start, Vec3d dir, Kind k) {
        ArrayList<Vec3d> path = new ArrayList<Vec3d>();
        Vec3d prev = start.add(dir.multiply(0.1));
        Vec3d vel = dir.multiply(k.speed);
        path.add(start);
        boolean hitEntity = false;
        for (int i = 0; i < 400; ++i) {
            Vec3d next = prev.add(vel);
            BlockHitResult blockHit = player.getEntityWorld().raycast(new RaycastContext(prev, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, (Entity)player));
            Vec3d segmentEnd = blockHit.getType() != HitResult.Type.MISS ? blockHit.getPos() : next;
            EntityHitResult entHit = this.ray(player, prev, segmentEnd);
            if (entHit != null) {
                path.add(entHit.getPos());
                hitEntity = true;
                break;
            }
            if (blockHit.getType() != HitResult.Type.MISS) {
                path.add(blockHit.getPos());
                break;
            }
            path.add(next);
            vel = new Vec3d(vel.x * (double)k.drag, (vel.y - k.gravity) * (double)k.drag, vel.z * (double)k.drag);
            prev = next;
            if (next.y < -64.0 || start.squaredDistanceTo(next) > 65536.0) break;
        }
        return new SimResult(path, hitEntity);
    }

    private EntityHitResult ray(ClientPlayerEntity player, Vec3d from, Vec3d to) {
        Box box = new Box(from, to).expand(0.4);
        List<Entity> list = player.getEntityWorld().getOtherEntities(player, box, e -> e instanceof LivingEntity && e.isAlive() && e != player && !e.isSpectator() && e.canHit());
        Entity closest = null;
        Vec3d hitPos = null;
        double best = Double.MAX_VALUE;
        for (Entity e2 : list) {
            double d;
            Optional<Vec3d> opt = e2.getBoundingBox().expand(0.3).raycast(from, to);
            if (opt.isEmpty() || !((d = from.squaredDistanceTo((Vec3d)opt.get())) < best)) continue;
            best = d;
            closest = e2;
            hitPos = (Vec3d)opt.get();
        }
        return closest == null ? null : new EntityHitResult(closest, hitPos);
    }

    private void draw(VertexConsumer lines, Matrix4f m, Vec3d cam, List<Vec3d> path, boolean hitEntity) {
        int n = path.size();
        int base = ModConfig.trajectoryColor & 0xFFFFFF;
        int br = base >> 16 & 0xFF;
        int bg = base >> 8 & 0xFF;
        int bb = base & 0xFF;
        for (int i = 0; i < n - 1; ++i) {
            int alpha;
            int bl;
            int g;
            int r;
            Vec3d a = path.get(i);
            Vec3d b = path.get(i + 1);
            float t = (float)i / (float)Math.max(1, n - 1);
            if (hitEntity) {
                r = 255;
                g = (int)(40.0f + 30.0f * (1.0f - t));
                bl = 40;
                alpha = (int)((0.8f + 0.2f * t) * 255.0f);
            } else {
                float f = 0.55f + 0.45f * t;
                r = MathHelper.clamp((int)((int)((float)br * f)), (int)0, (int)255);
                g = MathHelper.clamp((int)((int)((float)bg * f)), (int)0, (int)255);
                bl = MathHelper.clamp((int)((int)((float)bb * f)), (int)0, (int)255);
                alpha = (int)((0.7f + 0.3f * t) * 255.0f);
            }
            TrajectoryRenderer.edge(lines, m, (float)(a.x - cam.x), (float)(a.y - cam.y), (float)(a.z - cam.z), (float)(b.x - cam.x), (float)(b.y - cam.y), (float)(b.z - cam.z), r, g, bl, alpha);
        }
        Vec3d end = path.get(n - 1);
        float ex = (float)(end.x - cam.x);
        float ey = (float)(end.y - cam.y);
        float ez = (float)(end.z - cam.z);
        int sr = hitEntity ? 255 : br;
        int sg = hitEntity ? 70 : bg;
        int sb = hitEntity ? 70 : bb;
        for (int ring = 0; ring < 4; ++ring) {
            float ry = ((float)ring - 1.5f) * 0.06f;
            float rr = (float)Math.sqrt(Math.max(0.0f, 0.0256f - ry * ry));
            for (int s = 0; s < 12; ++s) {
                double a0 = (double)s * Math.PI * 2.0 / 12.0;
                double a1 = (double)(s + 1) * Math.PI * 2.0 / 12.0;
                TrajectoryRenderer.edge(lines, m, ex + (float)(Math.cos(a0) * (double)rr), ey + ry, ez + (float)(Math.sin(a0) * (double)rr), ex + (float)(Math.cos(a1) * (double)rr), ey + ry, ez + (float)(Math.sin(a1) * (double)rr), sr, sg, sb, 220);
            }
        }
    }

    private static void edge(VertexConsumer buf, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, int r, int g, int b, int a) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float len = (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-8f) {
            return;
        }
        buf.vertex(m, x1, y1, z1).color(r, g, b, a).normal(dx / len, dy / len, dz / len).lineWidth(2.0f);
        buf.vertex(m, x2, y2, z2).color(r, g, b, a).normal(dx / len, dy / len, dz / len).lineWidth(2.0f);
    }

    @Environment(EnvType.CLIENT)
    private static class Kind {
        final double speed;
        final double gravity;
        final float drag;
        final boolean multishot;
        final boolean pearl;

        Kind(double s, double g, float d, boolean m, boolean p) {
            this.speed = s;
            this.gravity = g;
            this.drag = d;
            this.multishot = m;
            this.pearl = p;
        }
    }

    @Environment(EnvType.CLIENT)
    private static class SimResult {
        final List<Vec3d> path;
        final boolean hitEntity;

        SimResult(List<Vec3d> p, boolean h) {
            this.path = p;
            this.hitEntity = h;
        }
    }
}
}
