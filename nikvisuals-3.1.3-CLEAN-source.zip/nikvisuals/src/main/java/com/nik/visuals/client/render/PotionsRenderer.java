package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class PotionsRenderer {
    private float appear;
    private int lastX, lastY, lastW, lastH;
    public static final int LINE = 15;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }

    public void render(DrawContext g, float pt) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        List<StatusEffectInstance> list = new ArrayList<>(p.getStatusEffects());
        boolean show = (ModConfig.potions && !list.isEmpty()) || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.16f);
        if (appear < 0.02f) return;

        float a = Anim.easeOutCubic(appear);
        float scale = Math.max(0.6f, Math.min(1.6f, ModConfig.potionsScale));
        int x = (int) (ModConfig.potionsX * mc.getWindow().getScaledWidth());
        int y = (int) (ModConfig.potionsY * mc.getWindow().getScaledHeight());

        if (list.isEmpty() && ModConfig.layoutEdit) {
            lastX = x; lastY = y; lastW = (int)(90 * scale); lastH = (int)(28 * scale);
            g.getMatrices().pushMatrix();
            g.getMatrices().translate(x, y);
            g.getMatrices().scale(scale);
            GuiDraw.glassPanel(g, 0), Style.alpha(Style.ACCENT_GLOW, a));
            g.drawText(mc.textRenderer, "Potions", 10, 10, Style.alpha(Style.TEXT_DIM, a), false);
            g.getMatrices().popMatrix();
            return;
        }
        if (list.isEmpty()) return;

        list.sort((a1, b1) -> {
            boolean ah = a1.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL;
            boolean bh = b1.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL;
            if (ah != bh) return ah ? 1 : -1;
            return Integer.compare(b1.getDuration(), a1.getDuration());
        });

        int maxW = 70;
        for (StatusEffectInstance e : list) {
            maxW = Math.max(maxW, 22 + mc.textRenderer.getWidth(fmt(e)) + 10);
        }
        int h = 8 + list.size() * LINE;
        lastX = x; lastY = y; lastW = (int)(maxW * scale); lastH = (int)(h * scale);

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x, y);
        g.getMatrices().scale(scale);
        // slide-in from left based on appear
        g.getMatrices().translate((1f - a) * -8f, 0);

        GuiDraw.glassPanel(g)));

        int row = 0;
        for (StatusEffectInstance e : list) {
            int ry = 5 + row * LINE;
            boolean harm = e.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL;
            int pill = harm ? Style.solidAlpha(0xAA4444, (int)(160 * a)) : Style.solidAlpha(0x33AA66, (int)(160 * a));
            GuiDraw.fillRounded(g, 5, ry, 12, 11, 3, pill);
            int textC = harm ? Style.alpha(0xFFFF9999, a) : Style.alpha(Style.TEXT, a);
            g.drawText(mc.textRenderer, fmt(e), 21, ry + 2, textC, false);
            row++;
        }
        g.getMatrices().popMatrix();
    }

    private String fmt(StatusEffectInstance e) {
        String name = e.getEffectType().value().getName().getString();
        if (name.length() > 11) name = name.substring(0, 10) + "…";
        int amp = e.getAmplifier();
        String a = amp > 0 ? " " + (amp + 1) : "";
        int sec = Math.max(0, e.getDuration() / 20);
        return name + a + " §8" + String.format("%d:%02d", sec / 60, sec % 60);
    }
}
