package com.nik.visuals.client.theme;

/** Unified green-black visual language for Nik Visuals 3.1 */
public final class Style {
    private Style() {}

    // Core palette — soft, not neon-harsh
    public static final int BG_DEEP     = 0xF00A0F0C;
    public static final int PANEL      = 0xE8101814;
    public static final int PANEL2     = 0xCC141E18;
    public static final int GLASS      = 0xAA0C1210;
    public static final int ACCENT     = 0xFF3DCC7A;
    public static final int ACCENT_DIM = 0x8833AA66;
    public static final int ACCENT_GLOW= 0x4033CC77;
    public static final int TEXT       = 0xFFE8F5EC;
    public static final int TEXT_DIM   = 0xFF7A9A88;
    public static final int DANGER     = 0xFFCC5555;
    public static final int WARN       = 0xFFDDBB44;
    public static final int OK         = 0xFF55CC88;
    public static final int ROW_HOV    = 0x2822AA55;
    public static final int DIVIDER    = 0x3322AA55;
    public static final int TRACK_OFF  = 0xFF2A332E;
    public static final int KNOB       = 0xFFF0FFF5;

    public static int alpha(int argb, float a) {
        int aa = Math.max(0, Math.min(255, (int)(((argb >>> 24) & 0xFF) * a)));
        return (aa << 24) | (argb & 0x00FFFFFF);
    }

    public static int solidAlpha(int rgb, int a) {
        return ((a & 0xFF) << 24) | (rgb & 0x00FFFFFF);
    }
}
