package com.nik.visuals.client.render;

import net.minecraft.client.gui.DrawContext;

public final class GuiDraw {
    private GuiDraw() {}

    public static void fillRounded(DrawContext g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        g.fill(x + r, y, x + w - r, y + h, color);
        g.fill(x, y + r, x + w, y + h - r, color);
        g.fill(x + 1, y + 1, x + r, y + r, color);
        g.fill(x + w - r, y + 1, x + w - 1, y + r, color);
        g.fill(x + 1, y + h - r, x + r, y + h - 1, color);
        g.fill(x + w - r, y + h - r, x + w - 1, y + h - 1, color);
    }

    public static void glassPanel(DrawContext g, int x, int y, int w, int h, int r, int fill, int border) {
        fillRounded(g, x - 1, y - 1, w + 2, h + 2, r + 1, border);
        fillRounded(g, x, y, w, h, r, fill);
        int sheen = (0x28 << 24) | 0xFFFFFF;
        g.fill(x + r, y + 1, x + w - r, y + 2, sheen);
    }

    public static void accentLine(DrawContext g, int x, int y, int w, int color) {
        g.fill(x, y, x + w, y + 1, color);
    }

    public static void hpBar(DrawContext g, int x, int y, int w, int h, float pct, int fill, int back) {
        pct = Math.max(0f, Math.min(1f, pct));
        fillRounded(g, x, y, w, h, Math.max(1, h / 2), back);
        int fw = Math.max(h, (int) (w * pct));
        if (pct > 0.01f) fillRounded(g, x, y, fw, h, Math.max(1, h / 2), fill);
    }

    /** Soft filled circle approx with nested rects */
    public static void fillSoftCircle(DrawContext g, int cx, int cy, int radius, int color) {
        if (radius <= 0) return;
        for (int dy = -radius; dy <= radius; dy++) {
            int span = (int) Math.sqrt(radius * radius - dy * dy);
            g.fill(cx - span, cy + dy, cx + span + 1, cy + dy + 1, color);
        }
    }
}
